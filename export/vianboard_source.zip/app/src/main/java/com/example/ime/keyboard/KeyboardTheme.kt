package com.example.ime.keyboard

import android.content.Context
import android.content.SharedPreferences

data class KeyboardTheme(
    val backgroundColor: Int = 0xFFECEFF1.toInt(),      // HeliBoard THEME_BLUE_GRAY background (#ECEFF1)
    val keyBackgroundColor: Int = 0xFFFFFFFF.toInt(),   // Pure white letter/number/space keycaps
    val actionKeyColor: Int = 0xFFDEE4E8.toInt(),       // HeliBoard lighter functionalKey (#DEE4E8)
    val keyBottomBevelColor: Int = 0xFFB0BEC5.toInt(),  // HeliBoard bottom bevel (#B0BEC5)
    val actionKeyBevelColor: Int = 0xFFB8C3CC.toInt(),  // HeliBoard lighter functional key bevel (#B8C3CC)
    val enterKeyColor: Int = 0xFF546E7A.toInt(),        // HeliBoard enter key (#546E7A)
    val enterKeyBevelColor: Int = 0xFF37474F.toInt(),   // HeliBoard enter key bottom bevel (#37474F)
    val accentColor: Int = 0xFF78909C.toInt(),          // HeliBoard THEME_BLUE_GRAY accent (#78909C)
    val textColor: Int = 0xFF37474F.toInt(),            // HeliBoard key_text_color (#37474F)
    val enterTextColor: Int = 0xFFFFFFFF.toInt(),       // White icon/text on Enter
    val hintColor: Int = 0x9937474F.toInt(),            // HeliBoard key hint (60% opacity)
    val borderColor: Int = 0x00000000,                  // No artificial stroke (HeliBoard layer-list aesthetic)
    val pressedKeyColor: Int = 0xFFB0BEC5.toInt(),      // Pressed state
    val popupBackgroundColor: Int = 0xFFCFD8DC.toInt(),  // Popup bubble
    val popupTextColor: Int = 0xFF37474F.toInt(),
    
    // Geometry (1-to-1 HeliBoard Material Light spec with Number Row)
    val keyHeightDp: Float = 50f,
    val toolbarHeightDp: Float = 40f,
    val keyCornerRadiusDp: Float = 10f,
    val borderWidthDp: Float = 0f,
    val horizontalGapDp: Float = 3.0f,
    val verticalGapDp: Float = 4.5f,
    val actionKeyGrayProgress: Int = 30,   // HeliBoard subtle light #DEE4E8
    val enterKeyColorProgress: Int = 50,   // HeliBoard #546E7A
    val showPopups: Boolean = true,
    val showHints: Boolean = true
) {
    companion object {
        const val PREFS_NAME = "vian_appearance_prefs"
        const val KEY_HEIGHT = "key_height"
        const val KEY_CORNER_RADIUS = "key_corner_radius"
        const val KEY_BORDER_WIDTH = "key_border_width"
        const val KEY_HORIZONTAL_GAP = "key_horizontal_gap"
        const val KEY_VERTICAL_GAP = "key_vertical_gap"
        const val KEY_ACTION_GRAY = "key_action_gray"
        const val KEY_ENTER_COLOR = "key_enter_color"
        const val KEY_SHOW_POPUPS = "key_show_popups"
        const val KEY_SHOW_HINTS = "key_show_hints"

        fun calculateActionKeyColor(grayProgress: Int): Int {
            if (grayProgress == 30) return 0xFFDEE4E8.toInt()
            if (grayProgress == 40) return 0xFFCFD8DC.toInt()
            val factor = grayProgress.coerceIn(0, 100) / 100f
            val startR = 241; val startG = 243; val startB = 244
            val endR = 120; val endG = 144; val endB = 156
            val r = (startR + (endR - startR) * factor).toInt()
            val g = (startG + (endG - startG) * factor).toInt()
            val b = (startB + (endB - startB) * factor).toInt()
            return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }

        fun calculateActionKeyBevelColor(grayProgress: Int): Int {
            if (grayProgress == 30) return 0xFFB8C3CC.toInt()
            if (grayProgress == 40) return 0xFF90A4AE.toInt()
            val factor = grayProgress.coerceIn(0, 100) / 100f
            val startR = 210; val startG = 218; val startB = 224
            val endR = 144; val endG = 164; val endB = 174
            val r = (startR + (endR - startR) * factor).toInt()
            val g = (startG + (endG - startG) * factor).toInt()
            val b = (startB + (endB - startB) * factor).toInt()
            return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }

        fun calculateEnterKeyColor(progress: Int): Int {
            if (progress == 50) return 0xFF546E7A.toInt()
            val factor = progress.coerceIn(0, 100)
            return if (factor <= 50) {
                val f = factor / 50f
                val r = (100 + (84 - 100) * f).toInt()
                val g = (116 + (110 - 116) * f).toInt()
                val b = (139 + (122 - 139) * f).toInt()
                (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            } else {
                val f = (factor - 50) / 50f
                val r = (84 + (15 - 84) * f).toInt()
                val g = (110 + (23 - 110) * f).toInt()
                val b = (122 + (42 - 122) * f).toInt()
                (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }

        fun loadFromPrefs(context: Context): KeyboardTheme {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val keyHeight = prefs.getFloat(KEY_HEIGHT, 50f)
            val cornerRadius = prefs.getFloat(KEY_CORNER_RADIUS, 10f)
            val borderWidth = prefs.getFloat(KEY_BORDER_WIDTH, 0f)
            val hGap = prefs.getFloat(KEY_HORIZONTAL_GAP, 3.0f)
            val vGap = prefs.getFloat(KEY_VERTICAL_GAP, 4.5f)
            val actionGray = prefs.getInt(KEY_ACTION_GRAY, 30)
            val enterColorProgress = prefs.getInt(KEY_ENTER_COLOR, 50)
            val showPopups = prefs.getBoolean(KEY_SHOW_POPUPS, true)
            val showHints = prefs.getBoolean(KEY_SHOW_HINTS, true)

            return KeyboardTheme(
                keyHeightDp = keyHeight,
                keyCornerRadiusDp = cornerRadius,
                borderWidthDp = borderWidth,
                borderColor = if (borderWidth > 0f) 0x1A000000 else 0x00000000,
                horizontalGapDp = hGap,
                verticalGapDp = vGap,
                actionKeyGrayProgress = actionGray,
                enterKeyColorProgress = enterColorProgress,
                actionKeyColor = calculateActionKeyColor(actionGray),
                actionKeyBevelColor = calculateActionKeyBevelColor(actionGray),
                enterKeyColor = calculateEnterKeyColor(enterColorProgress),
                showPopups = showPopups,
                showHints = showHints
            )
        }

        fun saveToPrefs(context: Context, theme: KeyboardTheme) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putFloat(KEY_HEIGHT, theme.keyHeightDp)
                .putFloat(KEY_CORNER_RADIUS, theme.keyCornerRadiusDp)
                .putFloat(KEY_BORDER_WIDTH, theme.borderWidthDp)
                .putFloat(KEY_HORIZONTAL_GAP, theme.horizontalGapDp)
                .putFloat(KEY_VERTICAL_GAP, theme.verticalGapDp)
                .putInt(KEY_ACTION_GRAY, theme.actionKeyGrayProgress)
                .putInt(KEY_ENTER_COLOR, theme.enterKeyColorProgress)
                .putBoolean(KEY_SHOW_POPUPS, theme.showPopups)
                .putBoolean(KEY_SHOW_HINTS, theme.showHints)
                .apply()
        }
    }
}
