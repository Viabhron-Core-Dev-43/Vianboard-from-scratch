package com.example.ime.keyboard

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.HapticFeedbackConstants
import androidx.core.content.ContextCompat
import com.example.R
import com.example.ime.toolbar.ToolbarPreferences
import com.example.ime.toolbar.ToolbarTool

class VianKeyboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var theme: KeyboardTheme = KeyboardTheme.loadFromPrefs(context)
        set(value) {
            val oldTheme = field
            field = value
            updatePaints()
            val dimensionsChanged = oldTheme.keyHeightDp != value.keyHeightDp ||
                                    oldTheme.toolbarHeightDp != value.toolbarHeightDp ||
                                    oldTheme.horizontalGapDp != value.horizontalGapDp ||
                                    oldTheme.verticalGapDp != value.verticalGapDp ||
                                    oldTheme.keyCornerRadiusDp != value.keyCornerRadiusDp
            if (dimensionsChanged) {
                ensureGeometry(forceRebuild = true)
                requestLayout()
            }
            invalidate()
        }

    val layout = KeyboardLayout()
    var onKeyAction: ((KeyData) -> Unit)? = null
    var onTextCommit: ((String) -> Unit)? = null
    var onActionExpand: (() -> Unit)? = null
    var onActionSelection: (() -> Unit)? = null
    var onActionClipboard: (() -> Unit)? = null

    // Toolbar tool callbacks
    var onToolbarToolClick: ((ToolbarTool) -> Unit)? = null
    var onToolbarToolLongClick: ((ToolbarTool) -> Unit)? = null
    var onAnchorLongClick: (() -> Unit)? = null
    var onCommaPopupSelected: ((String) -> Unit)? = null
    var onSymbolsLongClick: (() -> Unit)? = null
    var onSuggestionClick: ((String, Int) -> Unit)? = null
    var onSuggestionLongClick: ((KeyData, String, Int) -> Unit)? = null
    var onSpaceLongClick: ((KeyData) -> Unit)? = null
    var onLayoutUpdated: ((List<KeyData>, Int, Int) -> Unit)? = null
    var onModeChanged: ((KeyboardMode) -> Unit)? = null

    // Lite Mode toggle (Phase 3.2): Disables gesture trajectory processing
    var isLiteMode: Boolean = false

    private val toolbarPrefs = ToolbarPreferences(context)
    private val iconCache = mutableMapOf<Int, Drawable>()
    private var isLongPressTriggered = false

    // Horizontal scroll tracking for expanded toolbar
    private var isToolbarScrolling = false
    private var toolbarTouchStartX = 0f
    private var toolbarInitialScrollOffset = 0f
    private val touchSlop = android.view.ViewConfiguration.get(context).scaledTouchSlop.toFloat()

    private val popupWindow = KeyPopupWindow(context)

    // Canvas Paints (Pre-allocated)
    private val backgroundPaint = Paint()
    private val toolbarBackgroundPaint = Paint()
    private val keyBackgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val actionKeyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val enterKeyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pressedKeyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val keyBevelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val actionKeyBevelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val enterKeyBevelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val suggestionDividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x33000000
        style = Paint.Style.STROKE
    }
    private val tempRectF = RectF()
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT
    }
    private val actionTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT
    }
    private val enterTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.RIGHT
        typeface = Typeface.DEFAULT
    }
    private val enterHintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.RIGHT
        typeface = Typeface.DEFAULT
    }
    private val toolbarTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private val suggestionBoldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private val suggestionNormalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val suggestionDotsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val vaultPillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val vaultPillStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }

    // Vector Icon Paints
    private val iconStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val iconFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val enterIconStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val enterIconFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val pathHelper = Path()

    private var activePressedKey: KeyData? = null
    private var lastShiftPressTime = 0L
    private var isMultiPopupActive = false
    private var isCommaGridPopupActive = false
    private var isPeriodGridPopupActive = false
    internal var bottomNavInsetPx = 0f

    // Comma popup item definitions (Settings hardcoded + 4 customizable slots = 5 items in 1 row)
    private val commaPrefs by lazy { com.example.ime.settings.CommaPreferences(context) }

    private fun getDynamicCommaPopupItems(): Pair<List<String>, List<Int>> {
        val selectedSlots = commaPrefs.getSelectedSlots()
        val items = mutableListOf("Settings")
        val icons = mutableListOf(R.drawable.ic_settings)

        for (slot in selectedSlots) {
            when (slot) {
                "Voice" -> {
                    items.add("Voice")
                    icons.add(R.drawable.ic_mic)
                }
                "Desktop" -> {
                    items.add("Shortcuts")
                    icons.add(R.drawable.ic_desktop_shortcuts)
                }
                "Emoji" -> {
                    items.add("Emoji")
                    icons.add(R.drawable.ic_emoji_smileys)
                }
                "Log Keeper" -> {
                    items.add("Log Keeper")
                    icons.add(R.drawable.ic_log_keeper)
                }
                "Clipboard" -> {
                    items.add("Clipboard")
                    icons.add(R.drawable.ic_clipboard)
                }
                "Prompt List" -> {
                    items.add("Prompt List")
                    icons.add(R.drawable.ic_prompt_list)
                }
                "One Hand" -> {
                    items.add("One Hand")
                    icons.add(R.drawable.ic_one_hand)
                }
                "Floating" -> {
                    items.add("Floating")
                    icons.add(R.drawable.ic_floating_keyboard)
                }
                "Personal Vault" -> {
                    items.add("Personal Vault")
                    icons.add(R.drawable.ic_personal_vault)
                }
                "Security Vault" -> {
                    items.add("Security Vault")
                    icons.add(R.drawable.ic_security_vault)
                }
            }
        }
        return Pair(items, icons)
    }

    // Period popup symbol definitions (16 symbols: 2 rows of 8) matching Screenshot 1
    // Top Row: ! ? ; / ^ : ~ \
    // Bottom Row: " ' - ( ) [ ] {
    private val periodPopupItems = listOf(
        "!", "?", ";", "/", "^", ":", "~", "\\",
        "\"", "'", "-", "(", ")", "[", "]", "{"
    )

    // Long-press and repeat handler
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isRepeatingBackspace = false

    private val repeatBackspaceRunnable = object : Runnable {
        override fun run() {
            if (activePressedKey?.type == KeyType.DELETE) {
                isRepeatingBackspace = true
                activePressedKey?.let { onKeyAction?.invoke(it) }
                mainHandler.postDelayed(this, 50)
            }
        }
    }

    private val longPressRunnable = Runnable {
        activePressedKey?.let { key ->
            if (key.type == KeyType.DELETE) {
                mainHandler.post(repeatBackspaceRunnable)
            } else if (key.type == KeyType.ACTION_EXPAND) {
                isLongPressTriggered = true
                onAnchorLongClick?.invoke()
            } else if (key.type == KeyType.SPACE) {
                isLongPressTriggered = true
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                onSpaceLongClick?.invoke(key)
            } else if (key.type == KeyType.SUGGESTION) {
                isLongPressTriggered = true
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                val slotIndex = -(key.code + 200)
                onSuggestionLongClick?.invoke(key, key.label, slotIndex)
            } else if (key.type == KeyType.TOOLBAR_TOOL) {
                key.tool?.let { tool ->
                    isLongPressTriggered = true
                    onToolbarToolLongClick?.invoke(tool)
                }
            } else if (key.type == KeyType.COMMA) {
                isLongPressTriggered = true
                isCommaGridPopupActive = true
                val (dynItems, dynIcons) = getDynamicCommaPopupItems()
                val cols = dynItems.size.coerceAtLeast(1)
                popupWindow.showGridKeys(
                    anchor = this@VianKeyboardView,
                    key = key,
                    items = dynItems,
                    iconResIds = dynIcons,
                    cols = cols,
                    rows = 1,
                    theme = theme
                )
            } else if (key.type == KeyType.PERIOD) {
                isLongPressTriggered = true
                isPeriodGridPopupActive = true
                popupWindow.showGridKeys(
                    anchor = this@VianKeyboardView,
                    key = key,
                    items = periodPopupItems,
                    iconResIds = emptyList(),
                    cols = 8,
                    rows = 2,
                    theme = theme
                )
            } else if (key.type == KeyType.SYMBOLS_TOGGLE || key.type == KeyType.NUMPAD_TOGGLE) {
                if (key.label == "?123" || key.label.contains("12") || key.type == KeyType.NUMPAD_TOGGLE) {
                    isLongPressTriggered = true
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    onSymbolsLongClick?.invoke()
                }
            } else if (key.moreKeys.isNotEmpty() || !key.hintLabel.isNullOrEmpty()) {
                isMultiPopupActive = true
                val popupItems = if (key.moreKeys.isNotEmpty()) key.moreKeys else listOf(key.hintLabel!!)
                popupWindow.showMoreKeys(this@VianKeyboardView, key, popupItems, theme)
            }
        }
    }

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
        layout.pinnedTools = toolbarPrefs.getPinnedTools()
        layout.expandedTools = toolbarPrefs.getExpandedTools()
        layout.hidePinnedWhenExpanded = toolbarPrefs.hidePinnedWhenExpanded
        updatePaints()

        setOnApplyWindowInsetsListener { _, insets ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val navInsets = insets.getInsets(WindowInsets.Type.navigationBars())
                bottomNavInsetPx = navInsets.bottom.toFloat()
            } else {
                @Suppress("DEPRECATION")
                bottomNavInsetPx = insets.systemWindowInsetBottom.toFloat()
            }
            requestLayout()
            insets
        }
    }

    private fun updatePaints() {
        val density = resources.displayMetrics.density

        backgroundPaint.color = theme.backgroundColor
        toolbarBackgroundPaint.color = theme.backgroundColor
        keyBackgroundPaint.color = theme.keyBackgroundColor
        actionKeyPaint.color = theme.actionKeyColor
        enterKeyPaint.color = theme.enterKeyColor
        pressedKeyPaint.color = theme.pressedKeyColor

        // HeliBoard Rounded Base Border bevel colors
        keyBevelPaint.color = theme.keyBottomBevelColor
        actionKeyBevelPaint.color = theme.actionKeyBevelColor
        enterKeyBevelPaint.color = theme.enterKeyBevelColor

        suggestionDividerPaint.color = (theme.textColor and 0x00FFFFFF) or 0x26000000
        suggestionDividerPaint.strokeWidth = 1f * density

        borderPaint.color = theme.borderColor
        borderPaint.strokeWidth = theme.borderWidthDp * density

        textPaint.color = theme.textColor
        textPaint.textSize = 21f * density

        actionTextPaint.color = theme.textColor
        actionTextPaint.textSize = 14f * density

        enterTextPaint.color = theme.enterTextColor
        enterTextPaint.textSize = 18f * density

        hintPaint.color = theme.hintColor
        hintPaint.textSize = 10.5f * density

        enterHintPaint.color = 0xB3FFFFFF.toInt()
        enterHintPaint.textSize = 10f * density

        toolbarTextPaint.color = theme.textColor
        toolbarTextPaint.textSize = 14.5f * density
        toolbarTextPaint.typeface = Typeface.create("sans-serif", Typeface.NORMAL)

        suggestionBoldPaint.color = theme.textColor
        suggestionBoldPaint.textSize = 15.5f * density
        suggestionBoldPaint.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)

        suggestionNormalPaint.color = (theme.textColor and 0x00FFFFFF) or 0xB3000000.toInt()
        suggestionNormalPaint.textSize = 15f * density
        suggestionNormalPaint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

        suggestionDotsPaint.color = (theme.textColor and 0x00FFFFFF) or 0x80000000.toInt()

        vaultPillPaint.color = (theme.keyBackgroundColor and 0x00FFFFFF) or 0x33000000.toInt()
        vaultPillStrokePaint.color = (theme.textColor and 0x00FFFFFF) or 0x33000000.toInt()
        vaultPillStrokePaint.strokeWidth = 1f * density

        iconStrokePaint.color = theme.textColor
        iconStrokePaint.strokeWidth = 2.2f * density

        iconFillPaint.color = theme.textColor

        enterIconStrokePaint.color = theme.enterTextColor
        enterIconStrokePaint.strokeWidth = 2.4f * density

        enterIconFillPaint.color = theme.enterTextColor
    }

    fun reloadTheme() {
        theme = KeyboardTheme.loadFromPrefs(context)
        reloadToolbarConfiguration()
    }

    fun ensureGeometry(forceRebuild: Boolean = false): Boolean {
        if (width <= 0 || height <= 0) return false
        val density = resources.displayMetrics.density
        val changed = layout.ensureLayout(width.toFloat(), height.toFloat(), theme, density, bottomNavInsetPx, forceRebuild)
        if (changed) {
            onLayoutUpdated?.invoke(layout.keys, width, height)
        }
        return changed
    }

    fun setMode(newMode: KeyboardMode) {
        if (layout.mode != newMode) {
            layout.mode = newMode
            requestLayout()
            ensureGeometry(forceRebuild = true)
            invalidate()
            onModeChanged?.invoke(newMode)
        }
    }

    fun reloadToolbarConfiguration() {
        layout.pinnedTools = toolbarPrefs.getPinnedTools()
        layout.expandedTools = toolbarPrefs.getExpandedTools()
        layout.hidePinnedWhenExpanded = toolbarPrefs.hidePinnedWhenExpanded
        ensureGeometry(forceRebuild = true)
        invalidate()
    }

    fun toggleToolbarExpand() {
        layout.isToolbarExpanded = !layout.isToolbarExpanded
        layout.syncToolbarKeys()
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val density = resources.displayMetrics.density
        val rowCount = layout.getRowCountForMode(layout.mode)
        val rowsTotalHeight = (theme.keyHeightDp * rowCount * density)
        val toolbarHeight = (theme.toolbarHeightDp * density)
        val paddingVPx = KeyboardGeometry.HELIBOARD_PADDING_DP * density
        // Total keyboard height is determined by toolbar + rows + padding + insets.
        // Vertical gaps between keys are distributed inside the key area so changing vertical gap does not change the keyboard board height.
        val totalCalculatedHeight = (toolbarHeight + rowsTotalHeight + (paddingVPx * 2f) + bottomNavInsetPx).toInt()
        val height = totalCalculatedHeight.coerceAtLeast((180 * density).toInt())
        setMeasuredDimension(width, height)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val density = resources.displayMetrics.density
        val changed = layout.ensureLayout(w.toFloat(), h.toFloat(), theme, density, bottomNavInsetPx)
        if (changed) {
            onLayoutUpdated?.invoke(layout.keys, w, h)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (layout.cachedGeometry == null) {
            ensureGeometry()
        }
        val geo = layout.cachedGeometry ?: return
        val density = resources.displayMetrics.density
        val cornerRadius = theme.keyCornerRadiusDp * density
        val hasBorder = theme.borderWidthDp > 0

        // 1. Draw Keyboard Background
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), backgroundPaint)

        // 2. Draw Top Toolbar Items
        if (layout.isToolbarExpanded && layout.toolbarScrollBounds.width() > 0) {
            // A. Draw Anchor Key first (fixed, non-scrolling, 36dp square, circular button)
            val anchorKey = layout.toolbarKeys.firstOrNull { it.type == KeyType.ACTION_EXPAND }
            if (anchorKey != null) {
                val cx = (anchorKey.bounds.left + anchorKey.bounds.right) / 2f
                val cy = (anchorKey.bounds.top + anchorKey.bounds.bottom) / 2f
                val bgCircleRadius = 14.5f * density
                val bgPaint = if (anchorKey.isPressed) pressedKeyPaint else actionKeyPaint
                canvas.drawCircle(cx, cy, bgCircleRadius, bgPaint)
                val chevronRes = if (layout.isToolbarExpanded) R.drawable.ic_chevron_up else R.drawable.ic_chevron_right
                val iconRes = if (layout.isIncognitoActive) R.drawable.sym_keyboard_incognito_lxx else chevronRes
                drawCachedIcon(canvas, anchorKey.iconBounds, iconRes, theme.textColor)

                val divX = anchorKey.bounds.right + (3f * density)
                canvas.drawLine(divX, geo.dividerTopY, divX, geo.dividerBottomY, suggestionDividerPaint)
            }

            // B. Clip and translate scrollable tools tray (tools in middle)
            canvas.save()
            canvas.clipRect(geo.toolbarScrollBounds)
            canvas.translate(-layout.toolbarScrollOffset, 0f)

            for (key in layout.toolbarKeys) {
                if (key.code !in -300 downTo -399) continue
                val toolCx = (key.bounds.left + key.bounds.right) / 2f
                val toolCy = (key.bounds.top + key.bounds.bottom) / 2f
                if (key.isPressed) {
                    canvas.drawCircle(toolCx, toolCy, 14.5f * density, pressedKeyPaint)
                }

                if (key.type == KeyType.TOOLBAR_TOOL) {
                    key.tool?.let { tool ->
                        drawCachedIcon(canvas, key.iconBounds, tool.iconResId, theme.textColor)
                    }
                } else {
                    val textY = toolCy - ((toolbarTextPaint.descent() + toolbarTextPaint.ascent()) / 2)
                    canvas.drawText(key.label, toolCx, textY, toolbarTextPaint)
                }
            }
            canvas.restore()

            // C. Draw docked pinned tools (fixed on right edge, only if not hidden when expanded)
            if (!layout.hidePinnedWhenExpanded) {
                for (key in layout.toolbarKeys) {
                    if (key.code !in -400 downTo -499) continue
                    val toolCx = (key.bounds.left + key.bounds.right) / 2f
                    val toolCy = (key.bounds.top + key.bounds.bottom) / 2f
                    if (key.isPressed) {
                        canvas.drawCircle(toolCx, toolCy, 14.5f * density, pressedKeyPaint)
                    }
                    if (key.type == KeyType.TOOLBAR_TOOL) {
                        key.tool?.let { tool ->
                            drawCachedIcon(canvas, key.iconBounds, tool.iconResId, theme.textColor)
                        }
                    }
                }
            }
        } else {
            // Draw subtle slot dividers for suggestion bar matching HeliBoard
            if (layout.suggestions.size == 2) {
                canvas.drawLine(geo.dualDividerX, geo.dividerTopY, geo.dualDividerX, geo.dividerBottomY, suggestionDividerPaint)
            } else if (layout.suggestions.size >= 3) {
                canvas.drawLine(geo.divider1X, geo.dividerTopY, geo.divider1X, geo.dividerBottomY, suggestionDividerPaint)
                canvas.drawLine(geo.divider2X, geo.dividerTopY, geo.divider2X, geo.dividerBottomY, suggestionDividerPaint)
            }

            for (key in layout.toolbarKeys) {
                if (key.type == KeyType.ACTION_EXPAND) {
                    val cx = (key.bounds.left + key.bounds.right) / 2f
                    val cy = (key.bounds.top + key.bounds.bottom) / 2f
                    val bgCircleRadius = 14.5f * density
                    val bgPaint = if (key.isPressed) pressedKeyPaint else actionKeyPaint
                    canvas.drawCircle(cx, cy, bgCircleRadius, bgPaint)
                    val chevronRes = if (layout.isToolbarExpanded) R.drawable.ic_chevron_up else R.drawable.ic_chevron_right
                    val iconRes = if (layout.isIncognitoActive) R.drawable.sym_keyboard_incognito_lxx else chevronRes
                    drawCachedIcon(canvas, key.iconBounds, iconRes, theme.textColor)

                    val divX = key.bounds.right + (3f * density)
                    canvas.drawLine(divX, geo.dividerTopY, divX, geo.dividerBottomY, suggestionDividerPaint)
                } else if (key.type == KeyType.TOOLBAR_TOOL) {
                    val toolCx = (key.bounds.left + key.bounds.right) / 2f
                    val toolCy = (key.bounds.top + key.bounds.bottom) / 2f
                    if (key.isPressed) {
                        canvas.drawCircle(toolCx, toolCy, 14.5f * density, pressedKeyPaint)
                    }
                    key.tool?.let { tool ->
                        drawCachedIcon(canvas, key.iconBounds, tool.iconResId, theme.textColor)
                    }
                } else if (key.type == KeyType.SUGGESTION) {
                    canvas.save()
                    canvas.clipRect(key.bounds)

                    val isVaultCandidate = key.label.startsWith("🔒") || key.label.startsWith("🔓") || key.label.startsWith("🛡️")
                    val isClipboardCandidate = key.label.startsWith("📋")
                    val isPillCandidate = isVaultCandidate || isClipboardCandidate
                    val isCenterCandidate = key.code == -201
                    val paintToUse = if (isCenterCandidate) suggestionBoldPaint else suggestionNormalPaint

                    val keyCenterY = (key.bounds.top + key.bounds.bottom) / 2f
                    val keyCenterX = (key.bounds.left + key.bounds.right) / 2f

                    // Ellipsize candidate label gracefully if it exceeds available slot width
                    val maxTextWidth = (key.bounds.right - key.bounds.left) - (14f * density)
                    val displayLabel = if (maxTextWidth > 0f && paintToUse.measureText(key.label) > maxTextWidth) {
                        android.text.TextUtils.ellipsize(
                            key.label,
                            android.text.TextPaint(paintToUse),
                            maxTextWidth,
                            android.text.TextUtils.TruncateAt.END
                        ).toString()
                    } else {
                        key.label
                    }

                    if (isPillCandidate) {
                        val pillHeight = 28f * density
                        val pillPaddingH = 10f * density
                        val measuredTextW = paintToUse.measureText(displayLabel)
                        val pillWidth = (measuredTextW + (pillPaddingH * 2f)).coerceAtMost(key.bounds.width() - (4f * density))
                        val pillLeft = keyCenterX - (pillWidth / 2f)
                        val pillRight = keyCenterX + (pillWidth / 2f)
                        val pillTop = keyCenterY - (pillHeight / 2f)
                        val pillBottom = keyCenterY + (pillHeight / 2f)
                        val pillRect = RectF(pillLeft, pillTop, pillRight, pillBottom)
                        val pillRadius = 14f * density

                        val bgPaint = if (key.isPressed) pressedKeyPaint else vaultPillPaint
                        canvas.drawRoundRect(pillRect, pillRadius, pillRadius, bgPaint)
                        canvas.drawRoundRect(pillRect, pillRadius, pillRadius, vaultPillStrokePaint)
                    } else if (key.isPressed) {
                        canvas.drawRoundRect(key.bounds, 6f * density, 6f * density, pressedKeyPaint)
                    }

                    // For center candidate, offset text slightly upward to leave balanced room for the 3 dots
                    val yOffset = if (isCenterCandidate && !isPillCandidate && layout.suggestions.size >= 3) (-1.5f * density) else 0f
                    val textY = keyCenterY - ((paintToUse.descent() + paintToUse.ascent()) / 2f) + yOffset
                    canvas.drawText(displayLabel, keyCenterX, textY, paintToUse)

                    // Draw HeliBoard's authentic three-dot auto-correct indicator beneath the center word
                    if (isCenterCandidate && !isPillCandidate && key.label.isNotEmpty() && layout.suggestions.size >= 3) {
                        canvas.drawCircle(keyCenterX - geo.centerDotSpacing, geo.centerDotsY, geo.centerDotRadius, suggestionDotsPaint)
                        canvas.drawCircle(keyCenterX, geo.centerDotsY, geo.centerDotRadius, suggestionDotsPaint)
                        canvas.drawCircle(keyCenterX + geo.centerDotSpacing, geo.centerDotsY, geo.centerDotRadius, suggestionDotsPaint)
                    }

                    canvas.restore()
                }
            }
        }

        // 3. Draw Main Keys
        for (key in layout.keys) {
            val isActionKey = key.isSpecialKey && key.type != KeyType.ENTER
            val isEnter = key.type == KeyType.ENTER

            val currentBgPaint = when {
                key.isPressed -> pressedKeyPaint
                isEnter -> enterKeyPaint
                isActionKey -> actionKeyPaint
                else -> keyBackgroundPaint
            }

            val currentRadius = key.cornerRadius

            if (key.isPressed) {
                // Key pressed: flat depressed surface
                canvas.drawRoundRect(key.bounds, currentRadius, currentRadius, pressedKeyPaint)
                if (theme.borderWidthDp > 0f && borderPaint.strokeWidth > 0f) {
                    canvas.drawRoundRect(key.bounds, currentRadius, currentRadius, borderPaint)
                }
            } else {
                // 1. Bottom bevel layer (HeliBoard layer-list reproduction: only bottom edge shows dark bevel)
                val bevelPaint = when {
                    isEnter -> enterKeyBevelPaint
                    isActionKey -> actionKeyBevelPaint
                    else -> keyBevelPaint
                }
                canvas.drawRoundRect(key.bounds, currentRadius, currentRadius, bevelPaint)

                // 2. Top keycap surface inset at bottom by bevel height (precalculated in key.topCapBounds)
                canvas.drawRoundRect(key.topCapBounds, currentRadius, currentRadius, currentBgPaint)

                // 3. Crisp keycap border matching HeliBoard
                if (theme.borderWidthDp > 0f && borderPaint.strokeWidth > 0f) {
                    canvas.drawRoundRect(key.topCapBounds, currentRadius, currentRadius, borderPaint)
                }
            }

            // Key label or custom vector icon
            when (key.type) {
                KeyType.DELETE -> {
                    drawCachedIcon(canvas, key.iconBounds, R.drawable.sym_keyboard_delete_rounded, theme.textColor)
                }
                KeyType.SHIFT -> {
                    val (iconRes, tint) = when (layout.shiftState) {
                        ShiftState.OFF -> Pair(R.drawable.sym_keyboard_shift_rounded, theme.textColor)
                        ShiftState.ON -> Pair(R.drawable.sym_keyboard_shift_rounded, theme.accentColor)
                        ShiftState.CAPS_LOCK -> Pair(R.drawable.sym_keyboard_shift_lock_rounded, theme.accentColor)
                    }
                    drawCachedIcon(canvas, key.iconBounds, iconRes, tint)
                }
                KeyType.ENTER -> {
                    drawCachedIcon(canvas, key.iconBounds, R.drawable.sym_keyboard_return_rounded, theme.enterTextColor)
                }
                else -> {
                    val paintToUse = when {
                        key.type == KeyType.CHARACTER || key.type == KeyType.SPACE || key.type == KeyType.COMMA || key.type == KeyType.PERIOD -> textPaint
                        else -> actionTextPaint
                    }

                    if (key.type == KeyType.SPACE) {
                        if (key.label.isNotEmpty()) {
                            val textY = key.bounds.centerY() - ((hintPaint.descent() + hintPaint.ascent()) / 2)
                            canvas.drawText(key.label, key.bounds.centerX(), textY, hintPaint)
                        }
                    } else if (key.label.contains("\n")) {
                        val lines = key.label.split("\n")
                        val totalH = (lines.size * 12f * density)
                        var lineY = key.bounds.centerY() - (totalH / 2) + (8f * density)
                        for (line in lines) {
                            canvas.drawText(line, key.bounds.centerX(), lineY, paintToUse)
                            lineY += (12f * density)
                        }
                    } else {
                        val textY = key.labelY - ((paintToUse.descent() + paintToUse.ascent()) / 2)
                        canvas.drawText(key.label, key.labelX, textY, paintToUse)
                    }
                }
            }

            // Hint label (using precalculated hintX, hintY)
            if (theme.showHints && key.hintLabel != null) {
                if (key.type == KeyType.ENTER) {
                    canvas.drawText(key.hintLabel, key.hintX, key.hintY, enterHintPaint)
                } else if (key.type != KeyType.SPACE) {
                    canvas.drawText(key.hintLabel, key.hintX, key.hintY, hintPaint)
                }
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                isLongPressTriggered = false
                isToolbarScrolling = false
                toolbarTouchStartX = x
                toolbarInitialScrollOffset = layout.toolbarScrollOffset

                val key = layout.findKeyAt(x, y)
                if (key != null) {
                    activePressedKey = key
                    key.isPressed = true
                    isRepeatingBackspace = false
                    isMultiPopupActive = false
                    isCommaGridPopupActive = false
                    isPeriodGridPopupActive = false

                    mainHandler.postDelayed(longPressRunnable, 400L)
                    invalidate()
                }
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (isCommaGridPopupActive || isPeriodGridPopupActive) {
                    popupWindow.updateSelection(event.rawX, event.rawY)
                } else if (isMultiPopupActive) {
                    popupWindow.updateSelection(event.rawX, event.rawY)
                } else {
                    // Check if dragging/scrolling on the expanded toolbar
                    if (layout.isToolbarExpanded && layout.toolbarScrollBounds.contains(toolbarTouchStartX, y) && layout.maxToolbarScrollOffset > 0f) {
                        val deltaX = x - toolbarTouchStartX
                        if (isToolbarScrolling || Math.abs(deltaX) > touchSlop) {
                            isToolbarScrolling = true
                            mainHandler.removeCallbacks(longPressRunnable)
                            activePressedKey?.isPressed = false
                            activePressedKey = null

                            val newOffset = (toolbarInitialScrollOffset - deltaX).coerceIn(0f, layout.maxToolbarScrollOffset)
                            if (newOffset != layout.toolbarScrollOffset) {
                                layout.toolbarScrollOffset = newOffset
                                invalidate()
                            }
                            return true
                        }
                    }

                    val key = layout.findKeyAt(x, y)
                    if (key != activePressedKey) {
                        activePressedKey?.isPressed = false
                        mainHandler.removeCallbacks(longPressRunnable)
                        mainHandler.removeCallbacks(repeatBackspaceRunnable)
                        popupWindow.dismiss()

                        activePressedKey = key
                        key?.isPressed = true
                        if (key != null) {
                            mainHandler.postDelayed(longPressRunnable, 400L)
                        }
                        invalidate()
                    }
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                mainHandler.removeCallbacks(longPressRunnable)
                mainHandler.removeCallbacks(repeatBackspaceRunnable)

                if (isToolbarScrolling) {
                    isToolbarScrolling = false
                    activePressedKey?.isPressed = false
                    activePressedKey = null
                    invalidate()
                    return true
                }

                try {
                    if (isCommaGridPopupActive) {
                        val selected = popupWindow.getSelectedItem()
                        if (!selected.isNullOrEmpty()) {
                            onCommaPopupSelected?.invoke(selected)
                        }
                    } else if (isPeriodGridPopupActive) {
                        val selected = popupWindow.getSelectedItem()
                        if (!selected.isNullOrEmpty()) {
                            onTextCommit?.invoke(selected)
                        }
                    } else if (isMultiPopupActive) {
                        val selected = popupWindow.getSelectedItem()
                        if (!selected.isNullOrEmpty()) {
                            onTextCommit?.invoke(selected)
                        }
                    } else {
                        val key = activePressedKey
                        if (key != null && !isRepeatingBackspace && !isLongPressTriggered) {
                            handleKeySelection(key)
                        }
                    }
                } catch (e: Exception) {
                    com.example.logger.LogKeeper.logError(
                        component = "VianKeyboardView",
                        errorCode = "POPUP_SELECTION_ERROR",
                        errorDetails = "${e.javaClass.simpleName}: ${e.message}"
                    )
                } finally {
                    popupWindow.dismiss()
                    activePressedKey?.isPressed = false
                    activePressedKey = null
                    isRepeatingBackspace = false
                    isMultiPopupActive = false
                    isCommaGridPopupActive = false
                    isPeriodGridPopupActive = false
                    invalidate()
                }
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                mainHandler.removeCallbacks(longPressRunnable)
                mainHandler.removeCallbacks(repeatBackspaceRunnable)
                popupWindow.dismiss()
                activePressedKey?.isPressed = false
                activePressedKey = null
                isRepeatingBackspace = false
                isMultiPopupActive = false
                isCommaGridPopupActive = false
                isPeriodGridPopupActive = false
                isToolbarScrolling = false
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun handleKeySelection(key: KeyData) {
        when (key.type) {
            KeyType.SHIFT -> {
                val now = System.currentTimeMillis()
                layout.shiftState = when (layout.shiftState) {
                    ShiftState.OFF -> ShiftState.ON
                    ShiftState.ON -> {
                        if (now - lastShiftPressTime < 350) ShiftState.CAPS_LOCK else ShiftState.OFF
                    }
                    ShiftState.CAPS_LOCK -> ShiftState.OFF
                }
                lastShiftPressTime = now
                layout.updateShiftLabels()
                invalidate()
            }

            KeyType.SYMBOLS_TOGGLE -> {
                val newMode = when (layout.mode) {
                    KeyboardMode.CHARACTERS -> KeyboardMode.SYMBOLS_1
                    KeyboardMode.NUMPAD -> KeyboardMode.CHARACTERS
                    else -> KeyboardMode.CHARACTERS
                }
                setMode(newMode)
            }

            KeyType.SYMBOLS_MORE_TOGGLE -> {
                val newMode = if (layout.mode == KeyboardMode.SYMBOLS_1) KeyboardMode.SYMBOLS_2 else KeyboardMode.SYMBOLS_1
                setMode(newMode)
            }

            KeyType.NUMPAD_TOGGLE -> {
                setMode(KeyboardMode.NUMPAD)
            }

            KeyType.TOOLBAR_TOOL -> {
                key.tool?.let { onToolbarToolClick?.invoke(it) }
            }

            KeyType.ACTION_EXPAND -> {
                onActionExpand?.invoke()
            }

            KeyType.ACTION_SELECTION -> {
                onActionSelection?.invoke()
            }

            KeyType.ACTION_CLIPBOARD -> {
                onActionClipboard?.invoke()
            }

            KeyType.SUGGESTION -> {
                val slotIndex = -(key.code + 200)
                if (onSuggestionClick != null) {
                    onSuggestionClick?.invoke(key.label, slotIndex)
                } else {
                    onTextCommit?.invoke(key.label + " ")
                }
            }

            else -> {
                onKeyAction?.invoke(key)
                // Auto-reset Shift if single capitalized letter typed
                if (layout.shiftState == ShiftState.ON && key.type == KeyType.CHARACTER) {
                    layout.shiftState = ShiftState.OFF
                    layout.updateShiftLabels()
                    invalidate()
                }
            }
        }
    }

    override fun onDetachedFromWindow() {
        popupWindow.dismiss()
        super.onDetachedFromWindow()
    }

    // Vector Icon Renderers (Matching HeliBoard & Screenshot)

    /**
     * Backspace Tag Icon (⌫):
     * Pointed tag outline pointing to the left with a centered '✕'
     */
    private fun drawBackspaceIcon(canvas: Canvas, bounds: RectF, density: Float) {
        val iconW = 20f * density
        val iconH = 14f * density
        val cx = bounds.centerX()
        val cy = bounds.centerY()
        val left = cx - (iconW / 2)
        val top = cy - (iconH / 2)
        val right = cx + (iconW / 2)
        val bottom = cy + (iconH / 2)
        val arrowW = 6.5f * density

        pathHelper.reset()
        pathHelper.moveTo(left, cy)
        pathHelper.lineTo(left + arrowW, top)
        pathHelper.lineTo(right, top)
        pathHelper.lineTo(right, bottom)
        pathHelper.lineTo(left + arrowW, bottom)
        pathHelper.close()
        canvas.drawPath(pathHelper, iconStrokePaint)

        // Draw inner ✕
        val crossHalf = 3.2f * density
        val crossCx = cx + (arrowW * 0.28f)
        canvas.drawLine(crossCx - crossHalf, cy - crossHalf, crossCx + crossHalf, cy + crossHalf, iconStrokePaint)
        canvas.drawLine(crossCx + crossHalf, cy - crossHalf, crossCx - crossHalf, cy + crossHalf, iconStrokePaint)
    }

    /**
     * Shift Chevron Icon:
     * Clean upward chevron (^).
     * OFF: stroke outline matching text
     * ON: illuminated / thicker stroke or accent fill
     * CAPS_LOCK: illuminated chevron with horizontal lock underline
     */
    private fun drawShiftChevronIcon(canvas: Canvas, bounds: RectF, density: Float, state: ShiftState) {
        val chevronW = 14f * density
        val chevronH = 8.5f * density
        val cx = bounds.centerX()
        val cy = bounds.centerY() - (if (state == ShiftState.CAPS_LOCK) 2f * density else 0f)

        val left = cx - (chevronW / 2)
        val right = cx + (chevronW / 2)
        val top = cy - (chevronH / 2)
        val bottom = cy + (chevronH / 2)

        when (state) {
            ShiftState.OFF -> {
                pathHelper.reset()
                pathHelper.moveTo(left, bottom)
                pathHelper.lineTo(cx, top)
                pathHelper.lineTo(right, bottom)
                canvas.drawPath(pathHelper, iconStrokePaint)
            }
            ShiftState.ON -> {
                // Active single shift - illuminated bold chevron
                val activePaint = Paint(iconStrokePaint).apply {
                    color = theme.accentColor
                    strokeWidth = 3.2f * density
                }
                pathHelper.reset()
                pathHelper.moveTo(left, bottom)
                pathHelper.lineTo(cx, top)
                pathHelper.lineTo(right, bottom)
                canvas.drawPath(pathHelper, activePaint)
            }
            ShiftState.CAPS_LOCK -> {
                // Caps Lock - illuminated chevron with lock bar underneath
                val lockPaint = Paint(iconStrokePaint).apply {
                    color = theme.accentColor
                    strokeWidth = 3.0f * density
                }
                pathHelper.reset()
                pathHelper.moveTo(left, bottom)
                pathHelper.lineTo(cx, top)
                pathHelper.lineTo(right, bottom)
                canvas.drawPath(pathHelper, lockPaint)

                // Lock horizontal bar beneath chevron
                val barY = bottom + (5f * density)
                canvas.drawLine(cx - (5.5f * density), barY, cx + (5.5f * density), barY, lockPaint)
            }
        }
    }

    /**
     * Enter / Return Elbow Icon (↵):
     * White return path entering from right, going left, ending in arrow
     */
    private fun drawEnterReturnIcon(canvas: Canvas, bounds: RectF, density: Float) {
        val iconW = 18f * density
        val iconH = 13f * density
        val cx = bounds.centerX()
        val cy = bounds.centerY()

        val left = cx - (iconW / 2)
        val right = cx + (iconW / 2)
        val top = cy - (iconH / 2)
        val bottom = cy + (iconH / 2)
        val arrowSize = 4.5f * density

        pathHelper.reset()
        // Start top right, come down, turn left
        pathHelper.moveTo(right, top)
        pathHelper.lineTo(right, bottom)
        pathHelper.lineTo(left, bottom)
        canvas.drawPath(pathHelper, enterIconStrokePaint)

        // Draw left arrow head
        pathHelper.reset()
        pathHelper.moveTo(left, bottom)
        pathHelper.lineTo(left + arrowSize, bottom - arrowSize)
        pathHelper.moveTo(left, bottom)
        pathHelper.lineTo(left + arrowSize, bottom + arrowSize)
        canvas.drawPath(pathHelper, enterIconStrokePaint)
    }

    private fun drawCachedIcon(canvas: Canvas, iconBounds: android.graphics.Rect, resId: Int, tintColor: Int) {
        val drawable = iconCache.getOrPut(resId) {
            ContextCompat.getDrawable(context, resId)?.mutate() ?: return
        }
        drawable.bounds = iconBounds
        drawable.setTint(tintColor)
        drawable.draw(canvas)
    }

    private fun drawVectorIcon(canvas: Canvas, bounds: RectF, resId: Int, sizePx: Float, tintColor: Int) {
        val drawable = iconCache.getOrPut(resId) {
            ContextCompat.getDrawable(context, resId)?.mutate() ?: return
        }
        val left = (bounds.centerX() - (sizePx / 2f)).toInt()
        val top = (bounds.centerY() - (sizePx / 2f)).toInt()
        val right = (left + sizePx).toInt()
        val bottom = (top + sizePx).toInt()
        drawable.setBounds(left, top, right, bottom)
        drawable.setTint(tintColor)
        drawable.draw(canvas)
    }

    fun updateSuggestions(newSuggestions: List<String>) {
        if (layout.suggestions != newSuggestions) {
            layout.suggestions = newSuggestions
            layout.syncSuggestionKeys()
            invalidate()
        }
    }

    fun updateSpaceLabel(label: String) {
        val cleanLabel = if (label.equals("EN", ignoreCase = true)) "" else label
        if (layout.spaceLabel != cleanLabel) {
            layout.spaceLabel = cleanLabel
            val spaceKey = layout.keys.firstOrNull { it.type == KeyType.SPACE }
            if (spaceKey != null) {
                spaceKey.label = cleanLabel
            }
            invalidate()
        }
    }

    /**
     * Cold Surfaces Demotion (Phase 3.4): Purges transient symbol/numpad layout state and
     * popup windows on low-memory trim signals or keyboard close.
     */
    fun demoteColdSurfaces() {
        popupWindow.dismiss()
        if (layout.mode != KeyboardMode.CHARACTERS) {
            setMode(KeyboardMode.CHARACTERS)
        }
    }
}
