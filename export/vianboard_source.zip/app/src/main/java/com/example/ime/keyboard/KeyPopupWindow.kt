package com.example.ime.keyboard

import android.content.Context
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.View
import android.widget.PopupWindow
import androidx.core.content.ContextCompat

class KeyPopupWindow(private val context: Context) {

    private val popupWindow = PopupWindow(context).apply {
        setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        isTouchable = false
        isFocusable = false
        isOutsideTouchable = false
        elevation = 16f
    }

    private val popupView = PopupCanvasView(context)

    init {
        popupWindow.contentView = popupView
    }

    fun showSingleKey(anchor: View, key: KeyData, theme: KeyboardTheme) {
        popupView.mode = PopupMode.SINGLE
        popupView.theme = theme
        popupView.targetKey = key
        popupView.items = listOf(key.label)
        popupView.iconResIds = emptyList()
        popupView.numCols = 1
        popupView.numRows = 1
        popupView.selectedIndex = 0

        val density = context.resources.displayMetrics.density
        val popupWidth = (key.bounds.width() * 1.35f).toInt().coerceAtLeast((48 * density).toInt())
        val popupHeight = (key.bounds.height() * 1.35f).toInt().coerceAtLeast((56 * density).toInt())

        popupWindow.width = popupWidth
        popupWindow.height = popupHeight

        val location = IntArray(2)
        anchor.getLocationInWindow(location)

        val posX = (location[0] + key.bounds.centerX() - (popupWidth / 2)).toInt()
        val posY = (location[1] + key.bounds.top - popupHeight - (4 * density)).toInt()

        if (popupWindow.isShowing) {
            popupWindow.update(posX, posY, popupWidth, popupHeight)
            popupView.invalidate()
        } else {
            popupWindow.showAtLocation(anchor, Gravity.NO_GRAVITY, posX, posY)
        }
    }

    fun showMoreKeys(anchor: View, key: KeyData, items: List<String>, theme: KeyboardTheme) {
        if (items.isEmpty()) return
        popupView.mode = PopupMode.MULTI
        popupView.theme = theme
        popupView.targetKey = key
        popupView.items = items
        popupView.iconResIds = emptyList()
        popupView.numCols = items.size
        popupView.numRows = 1
        popupView.selectedIndex = 0

        val density = context.resources.displayMetrics.density
        val itemWidth = (38f * density)
        val popupWidth = (items.size * itemWidth + (12f * density)).toInt()
        val popupHeight = (54f * density).toInt()

        popupWindow.width = popupWidth
        popupWindow.height = popupHeight

        val windowLoc = IntArray(2)
        anchor.getLocationInWindow(windowLoc)
        val screenLoc = IntArray(2)
        anchor.getLocationOnScreen(screenLoc)

        // Center strip over the key, clamp to screen edges
        val screenWidth = context.resources.displayMetrics.widthPixels
        val desiredX = windowLoc[0] + key.bounds.centerX() - (popupWidth / 2)
        val clampedX = desiredX.coerceIn(8f * density, screenWidth - popupWidth - (8f * density)).toInt()
        val posY = (windowLoc[1] + key.bounds.top - popupHeight - (6 * density)).toInt()

        val desiredScreenX = screenLoc[0] + key.bounds.centerX() - (popupWidth / 2)
        val clampedScreenX = desiredScreenX.coerceIn(8f * density, screenWidth - popupWidth - (8f * density))

        popupView.popupWindowScreenX = clampedScreenX
        popupView.popupWindowScreenY = screenLoc[1] + key.bounds.top - popupHeight - (6 * density)
        popupView.itemWidth = itemWidth
        popupView.itemHeight = popupHeight.toFloat() - (8f * density)

        if (popupWindow.isShowing) {
            popupWindow.update(clampedX, posY, popupWidth, popupHeight)
            popupView.invalidate()
        } else {
            popupWindow.showAtLocation(anchor, Gravity.NO_GRAVITY, clampedX, posY)
        }
    }

    fun showGridKeys(
        anchor: View,
        key: KeyData,
        items: List<String>,
        iconResIds: List<Int>,
        cols: Int,
        rows: Int,
        theme: KeyboardTheme
    ) {
        if (items.isEmpty()) return
        popupView.mode = PopupMode.GRID
        popupView.theme = theme
        popupView.targetKey = key
        popupView.items = items
        popupView.iconResIds = iconResIds
        popupView.numCols = cols
        popupView.numRows = rows
        popupView.selectedIndex = 0

        val density = context.resources.displayMetrics.density
        val screenWidth = context.resources.displayMetrics.widthPixels
        val padding = 8f * density
        val maxAvailableWidth = screenWidth - (16f * density)
        val desiredCellWidth = 44f * density
        val cellWidth = if (cols * desiredCellWidth + (padding * 2) > maxAvailableWidth) {
            (maxAvailableWidth - (padding * 2)) / cols
        } else {
            desiredCellWidth
        }
        val cellHeight = 42f * density

        val popupWidth = (cols * cellWidth + (padding * 2)).toInt()
        val popupHeight = (rows * cellHeight + (padding * 2)).toInt()

        popupWindow.width = popupWidth
        popupWindow.height = popupHeight

        val windowLoc = IntArray(2)
        anchor.getLocationInWindow(windowLoc)
        val screenLoc = IntArray(2)
        anchor.getLocationOnScreen(screenLoc)

        val maxX = (screenWidth - popupWidth - (8f * density)).toInt()
        val clampedX = if (maxX >= (8f * density).toInt()) {
            (windowLoc[0] + key.bounds.centerX() - (popupWidth / 2f)).toInt().coerceIn((8f * density).toInt(), maxX)
        } else {
            (8f * density).toInt()
        }
        val posY = (windowLoc[1] + key.bounds.top - popupHeight - (8 * density)).toInt()

        // Track screen coordinates for rawX / rawY touch tracking
        val maxScreenX = screenWidth - popupWidth - (8f * density)
        val clampedScreenX = if (maxScreenX >= 8f * density) {
            (screenLoc[0] + key.bounds.centerX() - (popupWidth / 2f)).coerceIn(8f * density, maxScreenX)
        } else {
            8f * density
        }
        val screenPosY = screenLoc[1] + key.bounds.top - popupHeight - (8 * density)

        popupView.popupWindowScreenX = clampedScreenX
        popupView.popupWindowScreenY = screenPosY
        popupView.anchorKeyScreenY = screenLoc[1] + key.bounds.centerY()
        popupView.itemWidth = cellWidth
        popupView.itemHeight = cellHeight

        try {
            if (popupWindow.isShowing) {
                popupWindow.update(clampedX, posY, popupWidth, popupHeight)
                popupView.invalidate()
            } else if (anchor.isAttachedToWindow && anchor.windowToken != null) {
                popupWindow.showAtLocation(anchor, Gravity.NO_GRAVITY, clampedX, posY)
            }
        } catch (e: Exception) {
            // Guard against BadTokenException or window detach race conditions
        }
    }

    fun updateSelection(touchXOnScreen: Float, touchYOnScreen: Float = 0f) {
        if (popupView.items.isEmpty()) return
        val density = context.resources.displayMetrics.density

        if (popupView.mode == PopupMode.GRID) {
            val padding = 8f * density
            val relativeX = touchXOnScreen - popupView.popupWindowScreenX - padding
            val col = (relativeX / popupView.itemWidth).toInt().coerceIn(0, popupView.numCols - 1)

            // Calculate row:
            // Popup sits above the key: row 0 is top row, row 1 is bottom row.
            // When finger is in the upper half or above popup -> row 0 (top row)
            // When finger is in lower half or near the key -> row 1 (bottom row)
            val rowDividerY = popupView.popupWindowScreenY + padding + popupView.itemHeight
            val row = if (touchYOnScreen < rowDividerY) {
                0
            } else {
                1.coerceAtMost(popupView.numRows - 1)
            }

            val index = (row * popupView.numCols + col).coerceIn(0, popupView.items.size - 1)
            if (index != popupView.selectedIndex) {
                popupView.selectedIndex = index
                popupView.invalidate()
            }
        } else if (popupView.mode == PopupMode.MULTI) {
            val relativeX = touchXOnScreen - popupView.popupWindowScreenX - (6f * density)
            val index = (relativeX / popupView.itemWidth).toInt().coerceIn(0, popupView.items.size - 1)
            if (index != popupView.selectedIndex) {
                popupView.selectedIndex = index
                popupView.invalidate()
            }
        }
    }

    fun getSelectedItem(): String? {
        return popupView.items.getOrNull(popupView.selectedIndex)
    }

    fun isShowing(): Boolean = popupWindow.isShowing

    fun dismiss() {
        if (popupWindow.isShowing) {
            popupWindow.dismiss()
        }
    }

    private enum class PopupMode { SINGLE, MULTI, GRID }

    private class PopupCanvasView(context: Context) : View(context) {
        var mode = PopupMode.SINGLE
        var theme = KeyboardTheme()
        var targetKey: KeyData? = null
        var items: List<String> = emptyList()
        var iconResIds: List<Int> = emptyList()
        var selectedIndex: Int = 0
        var popupWindowScreenX: Float = 0f
        var popupWindowScreenY: Float = 0f
        var anchorKeyScreenY: Float = 0f
        var itemWidth: Float = 0f
        var itemHeight: Float = 0f
        var numCols: Int = 1
        var numRows: Int = 1

        private val drawableCache = mutableMapOf<Int, Drawable?>()

        private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            setShadowLayer(10f, 0f, 4f, 0x40000000)
        }
        private val selectedBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = 0xFF0284C7.toInt() // Accent Sky 600
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        private val selectedTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
            color = 0xFFFFFFFF.toInt()
        }

        init {
            setLayerType(LAYER_TYPE_SOFTWARE, null) // For shadow rendering
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val density = resources.displayMetrics.density
            backgroundPaint.color = theme.popupBackgroundColor
            textPaint.color = theme.popupTextColor
            textPaint.textSize = if (mode == PopupMode.SINGLE) 24f * density else 19f * density
            selectedTextPaint.textSize = 20f * density

            val rect = RectF(4f * density, 4f * density, width - (4f * density), height - (4f * density))
            val cornerRadius = 12f * density

            // 1. Draw rounded bubble
            canvas.drawRoundRect(rect, cornerRadius, cornerRadius, backgroundPaint)

            if (mode == PopupMode.SINGLE) {
                val label = items.firstOrNull() ?: ""
                val textY = rect.centerY() - ((textPaint.descent() + textPaint.ascent()) / 2)
                canvas.drawText(label, rect.centerX(), textY, textPaint)
            } else if (mode == PopupMode.GRID) {
                // 2-row multi-column grid
                val padding = 8f * density
                val startX = rect.left + (padding - 4f * density)
                val startY = rect.top + (padding - 4f * density)

                for (i in items.indices) {
                    val row = i / numCols
                    val col = i % numCols

                    val cellLeft = startX + (col * itemWidth)
                    val cellTop = startY + (row * itemHeight)
                    val cellRight = cellLeft + itemWidth
                    val cellBottom = cellTop + itemHeight

                    val isSelected = (i == selectedIndex)
                    val cellRect = RectF(cellLeft + (2f * density), cellTop + (2f * density), cellRight - (2f * density), cellBottom - (2f * density))

                    if (isSelected) {
                        val selRadius = 8f * density
                        canvas.drawRoundRect(cellRect, selRadius, selRadius, selectedBgPaint)
                    }

                    val iconRes = iconResIds.getOrNull(i) ?: 0
                    if (iconRes != 0) {
                        val drawable = drawableCache.getOrPut(iconRes) {
                            ContextCompat.getDrawable(context, iconRes) ?: return@getOrPut null
                        }
                        if (drawable != null) {
                            val iconSize = (20f * density).toInt()
                            val cx = cellRect.centerX().toInt()
                            val cy = cellRect.centerY().toInt()
                            drawable.setBounds(cx - iconSize / 2, cy - iconSize / 2, cx + iconSize / 2, cy + iconSize / 2)
                            drawable.setTint(if (isSelected) Color.WHITE else theme.popupTextColor)
                            drawable.draw(canvas)
                        }
                    } else {
                        val curPaint = if (isSelected) selectedTextPaint else textPaint
                        val textY = cellRect.centerY() - ((curPaint.descent() + curPaint.ascent()) / 2)
                        canvas.drawText(items[i], cellRect.centerX(), textY, curPaint)
                    }
                }
            } else {
                // Multi-key horizontal strip
                val startX = rect.left + (2f * density)

                for (i in items.indices) {
                    val itemLeft = startX + (i * itemWidth)
                    val itemRight = itemLeft + itemWidth
                    val itemRect = RectF(itemLeft, rect.top, itemRight, rect.bottom)

                    if (i == selectedIndex) {
                        val selRadius = 8f * density
                        val selInsetRect = RectF(itemLeft + (2f * density), rect.top + (2f * density), itemRight - (2f * density), rect.bottom - (2f * density))
                        canvas.drawRoundRect(selInsetRect, selRadius, selRadius, selectedBgPaint)

                        val textY = selInsetRect.centerY() - ((selectedTextPaint.descent() + selectedTextPaint.ascent()) / 2)
                        canvas.drawText(items[i], selInsetRect.centerX(), textY, selectedTextPaint)
                    } else {
                        val textY = itemRect.centerY() - ((textPaint.descent() + textPaint.ascent()) / 2)
                        canvas.drawText(items[i], itemRect.centerX(), textY, textPaint)
                    }
                }
            }
        }
    }
}
